package model;

public enum Status {
	HIDE,
	DENY
}
